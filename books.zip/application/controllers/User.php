<?php
class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('user_model');
				// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}


	// method hapus data buku berdasarkan id
	public function delete($username){
		$this->load->model('user_model');
		$username = str_replace('%20', ' ', $username);
		$this->user_model->deluser($username);

		

		// $this->user_model->delUser($username);
		// // arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/user');
	}

    public function edit($id){
    	$data['user'] = $this->user_model->showUser($id);

        $data['fullname'] = $_SESSION['fullname'];

        if (empty($data['user'])){
            show_404();
        }

        $data['username'] = $data['user']['username'];
        $data['fullname2'] = $data['user']['fullname'];
        $data['password'] = $data['user']['password'];
        $data['idrole'] = $data['user']['idrole'];
        $data['roles'] = $this->user_model->getRole();
        $data['stsUpload'] = 'update/'.$id;
        $data['isEdit'] = true;
        $data['ganti'] = 'edit user';

        $this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/user', $data);
        $this->load->view('dashboard/footer');
    }
public function insert(){
	 $data['fullname'] = $_SESSION['fullname'];


		$username = $_POST['username'];
		$fullname = $_POST['fullname'];
		$password = $_POST['password'];
		$idrole = $_POST['idrole'];
	$this->user_model->insertUser($username, $fullname, $password, $idrole);

        redirect('dashboard/user');


}
    public function update($id){

		$username = $_POST['username'];
		$fullname = $_POST['fullname'];
		$password = $_POST['password'];
		$idrole = $_POST['idrole'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->user_model->updateUser($username, $fullname, $password, $idrole, $id);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/user');
}	// method untuk mencari data buku berdasarkan 'key'
public function getuser(){
	$query=$this->db->get('users');
	return $query->result_array();
}
}
?>