<?php
class Book extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}
	public function view($id){
                $data['view_book'] = $this->book_model->showBook($id);

                $data['fullname'] = $_SESSION['fullname'];

                if (empty($data['view_book'])){
                show_404();
                }

                $data['idbuku'] = $data['view_book']['idbuku'];
                $data['judul'] = $data['view_book']['judul'];
                $data['pengarang'] = $data['view_book']['pengarang'];
                $data['penerbit'] = $data['view_book']['penerbit'];
                $data['idkategori'] = $data['view_book']['idkategori'];
                $data['img'] = $data['view_book']['imgfile'];
                $data['sinopsis'] = $data['view_book']['sinopsis'];
                $data['thnterbit'] = $data['view_book']['thnterbit'];

                $this->load->view('dashboard/header', $data);
                $this->load->view('dashboard/viewbook', $data);
                $this->load->view('dashboard/footer');
    }
   
	// method hapus data buku berdasarkan id
	public function delete($id){
		$this->book_model->delBook($id);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/books');
	}

	// method untuk tambah data buku
	public function insert(){


$target_dir = "c:/xampp/htdocs/books/assets/images/";		// target direktori fileupload
		
		// baca nama file upload
		$filename = $_FILES["imgcover"]["name"];

		// menggabungkan target dir dengan nama file
		$target_file = $target_dir . basename($filename);

		// proses upload
		if (move_uploaded_file($_FILES["imgcover"]["tmp_name"], $target_file)) {

		// baca data dari form insert buku
		$idbuku = $_POST['idbuku'];
		$judul = $_POST['judul'];
		$pengarang = $_POST['pengarang'];
		$penerbit = $_POST['penerbit'];
		$sinopsis = $_POST['sinopsis'];
		$thnterbit = $_POST['thnterbit'];
		$idkategori = $_POST['idkategori'];
		//$image = $_POST['imgcover']['name'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->book_model->insertBook($idbuku,$judul, $pengarang, $penerbit, $thnterbit, $sinopsis, $idkategori, $filename);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/books');
		} else {
			redirect('dashboard');
		}
	}

	// method untuk edit data buku berdasarkan id
	public function edit($id){
		$data['kategori'] = $this->book_model->getKategori();
                $data['view_book'] = $this->book_model->showBook($id);

                $data['fullname'] = $_SESSION['fullname'];

                if (empty($data['view_book'])){
                show_404();
                }

                $data['idbuku'] = $data['view_book']['idbuku'];
                $data['judul'] = $data['view_book']['judul'];
                $data['pengarang'] = $data['view_book']['pengarang'];
                $data['penerbit'] = $data['view_book']['penerbit'];
                $data['idkategori'] = $data['view_book']['idkategori'];
                $data['img'] = $data['view_book']['imgfile'];
                $data['sinopsis'] = $data['view_book']['sinopsis'];
                $data['thnterbit'] = $data['view_book']['thnterbit'];

                $this->load->view('dashboard/header', $data);
                $this->load->view('dashboard/editbook', $data);
                $this->load->view('dashboard/footer');

	}

	// method untuk update data buku berdasarkan id
	public function update(){
		$target_dir = base_url()."assets/images/";
		
		// baca nama file upload
		$filename = $_FILES["imgcover"]["name"];

		// menggabungkan target dir dengan nama file
		$target_file = $target_dir . basename($filename);

		// proses upload
		move_uploaded_file($_FILES["imgcover"]["tmp_name"], $target_file);

		// baca data dari form insert buku
		$idbuku = $_POST['idbuku'];
		$judul = $_POST['judul'];
		$pengarang = $_POST['pengarang'];
		$penerbit = $_POST['penerbit'];
		$sinopsis = $_POST['sinopsis'];
		$thnterbit = $_POST['thnterbit'];
		$idkategori = $_POST['idkategori'];
		$image =$_POST['imgcover'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->book_model->updatebook($idbuku,$judul, $pengarang, $penerbit, $thnterbit, $sinopsis, $idkategori, $filename);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/books');
	}

	// method untuk mencari data buku berdasarkan 'key'
	public function findbooks(){
			$this->load->database();
		 	$this->load->library('pagination');
		 	$this->load->model('book_model');

		 	if(!isset($_SESSION['key'])){
		 		$_SESSION['key'] = "";
		 	}

		 	$key = "";
		 	if(isset($_POST['key'])){
		 		$key = $_POST['key'];
		 		$_SESSION['key'] = $key;
		 	}else{
		 		$key = $_SESSION['key'];
		 	}
		 	

		 	
		 	$data['totalBuku'] = $this->book_model->hitungJumlah();

            $config['base_url'] = site_url('dashboard/books'); //site url
            $databuku = $this->book_model->findBook($key);
            $config['total_rows'] = count($databuku); //total row
            $config['per_page'] = 5;  //show record per halaman
            $config["uri_segment"] = 3;  // uri parameter
            $choice = $config["total_rows"] / $config["per_page"];

            $key = '';
            if(isset($_POST['key'])){
				$key = $_POST['key'];
				$_SESSION['key'] = $key;

			}else{
				$key = $_SESSION['key'];
			}
			
			
            $config["num_links"] = floor($choice);
 			
            // Membuat Style pagination untuk BootStrap v4
            $config['first_link']       = 'First';
            $config['last_link']        = 'Last';
            $config['next_link']        = 'Next';
            $config['prev_link']        = 'Prev';
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tagl_close']  = '</span>Next</li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tagl_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tagl_close']  = '</span></li>';
 
            
            $this->pagination->initialize($config);


            $data['pageKeBerapa'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
 
            
            $data['listbuku'] = array_slice($databuku, $data['pageKeBerapa'], $config['per_page']);       
 			
           // $data['pagination'] = $this->pagination->create_links();
            $data['paginationa'] = $this->pagination->create_links();



		  	$data['fullname'] = $_SESSION['fullname'];
			// baca key dari form cari data
			$key = $_POST['key'];

			// panggil method findBook() dari model book_model untuk menjalankan query cari data
			

			// tampilkan hasil pencarian di view 'dashboard/books'
			$this->load->view('dashboard/header', $data);
        	$this->load->view('dashboard/books', $data);
        	$this->load->view('dashboard/footer');
	}
	// method untuk tambah kategori
	public function kategori(){


		$kategori = $_POST['kategori'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->book_model->insertKategori($kategori);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/books');
	}
	}
?>